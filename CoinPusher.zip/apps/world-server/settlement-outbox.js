const OUTBOX_KIND = 'yes-pusher-settlement-outbox';
const OUTBOX_VERSION = 1;
const DEFAULT_YES_PER_COIN_RAW = '1000000000000000000';

function cleanUrl(value) {
  return String(value ?? '').trim().replace(/\/+$/, '');
}

function cleanString(value) {
  return String(value ?? '').trim();
}

function whole(value) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(0, Math.floor(number)) : 0;
}

function walletFromPlayerId(playerId) {
  const value = cleanString(playerId);
  return value.startsWith('wallet:') ? value.slice('wallet:'.length).toLowerCase() : null;
}

function safeBigInt(value, fallback = 0n) {
  try {
    const raw = String(value ?? '').trim();
    if (!raw) return fallback;
    const parsed = BigInt(raw);
    return parsed >= 0n ? parsed : fallback;
  } catch {
    return fallback;
  }
}

function compactResponse(value) {
  if (value == null) return null;
  if (typeof value !== 'object') return String(value).slice(0, 1000);
  try {
    return JSON.parse(JSON.stringify(value));
  } catch {
    return null;
  }
}

async function readPayload(response) {
  const text = await response.text().catch(() => '');
  if (!text) return { ok: response.ok };
  try {
    return JSON.parse(text);
  } catch {
    return { ok: response.ok, text: text.slice(0, 1000) };
  }
}

export function settlementConfigFromEnv(env = process.env) {
  const apiBaseUrl = cleanUrl(env.YF_API_BASE_URL);
  const appKey = cleanString(env.YF_APP_KEY);
  const bucketId = cleanString(env.YF_BUCKET_ID);
  const creditGrantUrl = cleanUrl(env.YF_CREDIT_GRANT_URL);
  const yesPerCoinRaw = safeBigInt(env.YES_PUSHER_YES_PER_COIN_RAW, BigInt(DEFAULT_YES_PER_COIN_RAW)).toString();
  return {
    apiBaseUrl,
    appKey,
    bucketId,
    creditGrantUrl,
    yesPerCoinRaw,
    appSlug: cleanString(env.YES_PUSHER_APP_SLUG) || 'yes-pusher',
    eventSubmissionEnabled: Boolean(apiBaseUrl && appKey && bucketId),
    creditSubmissionEnabled: Boolean(creditGrantUrl && appKey && bucketId),
  };
}

export class SettlementOutbox {
  constructor(raw = null, {
    config = settlementConfigFromEnv(),
    fetchImpl = globalThis.fetch,
    now = () => Date.now(),
  } = {}) {
    this.config = config;
    this.fetchImpl = fetchImpl;
    this.now = now;
    this.records = new Map();
    this.processing = false;
    this.restore(raw);
  }

  integrationStatus() {
    return {
      bucketId: this.config.bucketId || null,
      eventSubmissionConfigured: this.config.eventSubmissionEnabled,
      creditSubmissionConfigured: this.config.creditSubmissionEnabled,
      payoutMode: this.config.creditSubmissionEnabled ? 'yokefellow' : 'record-only',
      yesPerCoinRaw: this.config.yesPerCoinRaw,
    };
  }

  enqueue(result) {
    const turnId = cleanString(result?.id);
    if (!turnId) throw new Error('A completed turn id is required for settlement');
    const existing = this.records.get(turnId);
    if (existing) return { ...existing };

    const wallet = walletFromPlayerId(result?.playerId);
    const coinsWon = whole(result?.coinsWon);
    const amountYesRaw = (BigInt(coinsWon) * safeBigInt(this.config.yesPerCoinRaw, BigInt(DEFAULT_YES_PER_COIN_RAW))).toString();
    const createdAt = new Date(this.now()).toISOString();
    const creditStatus = !wallet
      ? 'wallet_required'
      : coinsWon === 0
        ? 'no_payout'
        : this.config.creditSubmissionEnabled
          ? 'pending'
          : 'recorded';
    const eventStatus = !wallet
      ? 'wallet_required'
      : this.config.eventSubmissionEnabled
        ? 'pending'
        : 'disabled';

    const record = {
      id: turnId,
      externalRef: `yes-pusher:turn:${turnId}`,
      playerId: cleanString(result?.playerId),
      wallet,
      bucketId: this.config.bucketId || null,
      turnNumber: whole(result?.number ?? result?.turnNumber),
      coinsDropped: whole(result?.coinsDropped),
      coinsWon,
      coinsLost: whole(result?.coinsLost),
      lifetimeCoinsWon: whole(result?.lifetimeCoinsWon),
      skinDropEarned: whole(result?.skinDropEarned),
      pendingSkinMilestones: whole(result?.pendingSkinMilestones),
      amountYesRaw,
      creditStatus,
      eventStatus,
      attempts: 0,
      nextAttemptAtMs: this.now(),
      lastError: null,
      creditResponse: null,
      eventResponse: null,
      createdAt,
      updatedAt: createdAt,
      confirmedAt: null,
    };
    this.records.set(turnId, record);
    return { ...record };
  }

  get(turnId) {
    const record = this.records.get(cleanString(turnId));
    return record ? { ...record } : null;
  }

  viewForPlayer(playerId) {
    const id = cleanString(playerId);
    const records = [...this.records.values()]
      .filter((record) => record.playerId === id)
      .sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt));
    const pending = records.filter((record) => ['pending', 'failed'].includes(record.creditStatus)).length;
    const owedYesRaw = records
      .filter((record) => ['recorded', 'pending', 'failed'].includes(record.creditStatus))
      .reduce((sum, record) => sum + safeBigInt(record.amountYesRaw), 0n)
      .toString();
    return {
      pendingCount: pending,
      recordedOwedYesRaw: owedYesRaw,
      last: records[0] ? { ...records[0] } : null,
      integration: this.integrationStatus(),
    };
  }

  async submitEvent(record) {
    if (record.eventStatus !== 'pending' || !this.config.eventSubmissionEnabled) return false;
    const url = `${this.config.apiBaseUrl}/buckets/${encodeURIComponent(this.config.bucketId)}/offering-events`;
    const response = await this.fetchImpl(url, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-yf-app-key': this.config.appKey,
        'x-idempotency-key': `${record.externalRef}:event`,
      },
      body: JSON.stringify({
        wallet: record.wallet,
        appSlug: this.config.appSlug,
        eventType: 'turn_completed',
        metrics: {
          coinsDropped: record.coinsDropped,
          coinsWon: record.coinsWon,
          coinsLost: record.coinsLost,
          lifetimeCoinsWon: record.lifetimeCoinsWon,
          skinDropEarned: record.skinDropEarned,
          pendingSkinMilestones: record.pendingSkinMilestones,
        },
        meta: {
          eventId: record.externalRef,
          turnId: record.id,
          turnNumber: record.turnNumber,
          externalRef: record.externalRef,
          amountYesRaw: record.amountYesRaw,
        },
      }),
    });
    const payload = await readPayload(response);
    if (!response.ok || payload?.ok === false) {
      throw new Error(payload?.error?.message || payload?.error || `Offering event failed (${response.status})`);
    }
    record.eventStatus = 'submitted';
    record.eventResponse = compactResponse(payload);
    return true;
  }

  async submitCredit(record) {
    if (record.creditStatus !== 'pending' || !this.config.creditSubmissionEnabled) return false;
    const response = await this.fetchImpl(this.config.creditGrantUrl, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-yf-app-key': this.config.appKey,
        'x-idempotency-key': record.externalRef,
      },
      body: JSON.stringify({
        bucketId: this.config.bucketId,
        wallet: record.wallet,
        amountYesRaw: record.amountYesRaw,
        source: this.config.appSlug,
        externalRef: record.externalRef,
        memo: `YES Pusher turn ${record.turnNumber}: ${record.coinsWon} coin${record.coinsWon === 1 ? '' : 's'} won`,
        meta: {
          turnId: record.id,
          turnNumber: record.turnNumber,
          coinsDropped: record.coinsDropped,
          coinsWon: record.coinsWon,
          lifetimeCoinsWon: record.lifetimeCoinsWon,
        },
      }),
    });
    const payload = await readPayload(response);
    if (!response.ok || payload?.ok === false) {
      throw new Error(payload?.error?.message || payload?.error || `YES credit settlement failed (${response.status})`);
    }
    record.creditStatus = 'confirmed';
    record.creditResponse = compactResponse(payload);
    record.confirmedAt = new Date(this.now()).toISOString();
    return true;
  }

  async process({ limit = 10 } = {}) {
    if (this.processing || typeof this.fetchImpl !== 'function') return false;
    this.processing = true;
    let changed = false;
    try {
      const due = [...this.records.values()]
        .filter((record) => (
          (record.creditStatus === 'pending' || record.eventStatus === 'pending')
          && Number(record.nextAttemptAtMs ?? 0) <= this.now()
        ))
        .sort((a, b) => Number(a.nextAttemptAtMs ?? 0) - Number(b.nextAttemptAtMs ?? 0))
        .slice(0, Math.max(1, whole(limit)));

      for (const record of due) {
        record.attempts += 1;
        record.lastError = null;
        try {
          const eventChanged = await this.submitEvent(record);
          const creditChanged = await this.submitCredit(record);
          changed = changed || eventChanged || creditChanged;
          if (record.eventStatus === 'pending' || record.creditStatus === 'pending') {
            record.nextAttemptAtMs = this.now() + 5_000;
          }
        } catch (error) {
          record.lastError = error instanceof Error ? error.message : 'Settlement submission failed';
          if (record.creditStatus === 'pending') record.creditStatus = 'failed';
          if (record.eventStatus === 'pending') record.eventStatus = 'failed';
          const delay = Math.min(5 * 60_000, 2_000 * (2 ** Math.min(record.attempts, 7)));
          record.nextAttemptAtMs = this.now() + delay;
          changed = true;
        }
        record.updatedAt = new Date(this.now()).toISOString();
      }
    } finally {
      this.processing = false;
    }
    return changed;
  }

  retryFailed() {
    let changed = false;
    const now = this.now();
    for (const record of this.records.values()) {
      if (Number(record.nextAttemptAtMs ?? 0) > now) continue;
      let recordChanged = false;
      if (record.creditStatus === 'failed' && this.config.creditSubmissionEnabled) {
        record.creditStatus = 'pending';
        recordChanged = true;
      }
      if (record.eventStatus === 'failed' && this.config.eventSubmissionEnabled) {
        record.eventStatus = 'pending';
        recordChanged = true;
      }
      if (recordChanged) {
        record.updatedAt = new Date(now).toISOString();
        changed = true;
      }
    }
    return changed;
  }

  serialize() {
    return {
      kind: OUTBOX_KIND,
      version: OUTBOX_VERSION,
      records: [...this.records.values()],
    };
  }

  restore(raw) {
    if (!raw || raw.kind !== OUTBOX_KIND || raw.version !== OUTBOX_VERSION || !Array.isArray(raw.records)) return false;
    for (const value of raw.records) {
      const id = cleanString(value?.id);
      if (!id) continue;
      const record = {
        ...value,
        id,
        attempts: whole(value.attempts),
        nextAttemptAtMs: Number(value.nextAttemptAtMs ?? 0) || 0,
        amountYesRaw: safeBigInt(value.amountYesRaw).toString(),
      };
      if (!record.bucketId && this.config.bucketId) record.bucketId = this.config.bucketId;
      if (record.creditStatus === 'recorded' && this.config.creditSubmissionEnabled && record.wallet && safeBigInt(record.amountYesRaw) > 0n) {
        record.creditStatus = 'pending';
        record.nextAttemptAtMs = this.now();
      }
      if (record.eventStatus === 'disabled' && this.config.eventSubmissionEnabled && record.wallet) {
        record.eventStatus = 'pending';
        record.nextAttemptAtMs = this.now();
      }
      if (record.creditStatus === 'failed' && this.config.creditSubmissionEnabled && record.nextAttemptAtMs <= this.now()) record.creditStatus = 'pending';
      if (record.eventStatus === 'failed' && this.config.eventSubmissionEnabled && record.nextAttemptAtMs <= this.now()) record.eventStatus = 'pending';
      this.records.set(id, record);
    }
    return true;
  }
}

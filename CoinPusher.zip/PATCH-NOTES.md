# CoinPusher 35 — Wallet Identity and Settlement Outbox

Built from `CoinPusher(18).zip` without changing the approved cabinet, pusher, peg board, coin physics, centered tower, loaded side banks, camera, payout boundaries, or turn timing.

## Added

- Injected EVM wallet connection and signed challenge-response login.
- Five-minute single-use challenges and 24-hour HTTP-only server sessions.
- Wallet address as the authoritative shared-world player ID.
- Wallet-required queue control by default while unsigned visitors remain spectators.
- Protection against unsigned `wallet:` player-ID impersonation.
- Automatic shared-world identity refresh when the connected wallet account changes.
- Durable settlement outbox persisted to `.world-data/settlements.json`.
- One idempotent settlement record per completed turn.
- Per-turn YES amount calculation through `YES_PUSHER_YES_PER_COIN_RAW`.
- Existing Yokefellow bucket offering-event submission using `turn_completed` metrics.
- Explicit turn event identity for earned NFT/output duplicate protection.
- Optional direct bucket-credit submission through `YF_CREDIT_GRANT_URL`.
- Honest record-only mode when the supplied Yokefellow SDK has no configured direct credit route.
- Separate pending, confirmed, failed, owed, no-payout, and wallet-required result states.
- Exponential retry backoff that survives server restarts.
- Local `.env` loading with a documented `.env.example`.

## Security and correctness

- Wallet signatures never spend YES or send a transaction.
- Queue and turn commands use the verified HTTP-only session rather than trusting browser-supplied wallet text.
- Active Server-Sent Event connections retain the identity actually verified for that connection.
- Turn IDs are permanent idempotency keys for both the event and credit paths.
- The UI never labels a recorded owed amount as confirmed credit.

## Validation

- `npm test` — 25 tests pass.
- `npm run build` — passes.
- Tests cover signature verification, challenge expiration, one-time challenges, wallet-required server control, unsigned wallet-ID downgrade, idempotent outbox records, configured event/credit submission, and retry backoff.

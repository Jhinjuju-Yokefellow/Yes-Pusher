import test from 'node:test';
import assert from 'node:assert/strict';
import { SettlementOutbox, settlementConfigFromEnv } from '../apps/world-server/settlement-outbox.js';

function result(overrides = {}) {
  return {
    id: 'turn-10',
    playerId: 'wallet:0x1111111111111111111111111111111111111111',
    number: 10,
    coinsDropped: 5,
    coinsWon: 3,
    coinsLost: 2,
    lifetimeCoinsWon: 63,
    skinDropEarned: 0,
    pendingSkinMilestones: 0,
    ...overrides,
  };
}

function config(overrides = {}) {
  return {
    apiBaseUrl: '',
    appKey: '',
    bucketId: '',
    creditGrantUrl: '',
    yesPerCoinRaw: '1000000000000000000',
    appSlug: 'yes-pusher',
    eventSubmissionEnabled: false,
    creditSubmissionEnabled: false,
    ...overrides,
  };
}


test('settlement configuration defaults to one YES per coin when the environment value is missing or blank', () => {
  assert.equal(settlementConfigFromEnv({}).yesPerCoinRaw, '1000000000000000000');
  assert.equal(settlementConfigFromEnv({ YES_PUSHER_YES_PER_COIN_RAW: '' }).yesPerCoinRaw, '1000000000000000000');
});

test('settlement outbox records an idempotent owed balance without claiming it was credited', () => {
  const outbox = new SettlementOutbox(null, { config: config(), fetchImpl: null });
  const first = outbox.enqueue(result());
  const duplicate = outbox.enqueue(result({ coinsWon: 99 }));

  assert.equal(first.creditStatus, 'recorded');
  assert.equal(first.amountYesRaw, '3000000000000000000');
  assert.equal(duplicate.amountYesRaw, first.amountYesRaw);
  assert.equal(outbox.serialize().records.length, 1);
  assert.equal(outbox.viewForPlayer(first.playerId).recordedOwedYesRaw, first.amountYesRaw);
  assert.equal(outbox.integrationStatus().payoutMode, 'record-only');
});


test('record-only settlements become pending when the credit integration is configured later', () => {
  const recorded = new SettlementOutbox(null, { config: config(), fetchImpl: null });
  recorded.enqueue(result());
  const restored = new SettlementOutbox(recorded.serialize(), {
    config: config({
      appKey: 'app-secret',
      bucketId: 'bucket-1',
      creditGrantUrl: 'https://yf.example/credit',
      creditSubmissionEnabled: true,
    }),
    fetchImpl: async () => new Response(JSON.stringify({ ok: true }), { status: 200 }),
    now: () => 5_000,
  });
  const value = restored.get('turn-10');
  assert.equal(value.creditStatus, 'pending');
  assert.equal(value.bucketId, 'bucket-1');
  assert.equal(value.nextAttemptAtMs, 5_000);
});

test('configured outbox submits the turn event and YES credit with separate idempotency keys', async () => {
  const calls = [];
  const fetchImpl = async (url, init) => {
    calls.push({ url, init, body: JSON.parse(init.body) });
    return new Response(JSON.stringify({ ok: true, receiptId: `receipt-${calls.length}` }), {
      status: 200,
      headers: { 'content-type': 'application/json' },
    });
  };
  const outbox = new SettlementOutbox(null, {
    config: config({
      apiBaseUrl: 'https://yf.example/api/sdk/v1',
      appKey: 'app-secret',
      bucketId: 'bucket-1',
      creditGrantUrl: 'https://yf.example/api/sdk/v1/bucket-credit/grant',
      eventSubmissionEnabled: true,
      creditSubmissionEnabled: true,
    }),
    fetchImpl,
  });
  outbox.enqueue(result());
  assert.equal(await outbox.process(), true);

  const record = outbox.get('turn-10');
  assert.equal(record.eventStatus, 'submitted');
  assert.equal(record.creditStatus, 'confirmed');
  assert.equal(calls.length, 2);
  assert.match(calls[0].url, /offering-events$/);
  assert.equal(calls[0].init.headers['x-idempotency-key'], 'yes-pusher:turn:turn-10:event');
  assert.equal(calls[1].init.headers['x-idempotency-key'], 'yes-pusher:turn:turn-10');
  assert.equal(calls[1].body.amountYesRaw, '3000000000000000000');
});

test('failed settlement honors exponential backoff before becoming retryable', async () => {
  let now = 1_000;
  let fail = true;
  const fetchImpl = async () => {
    if (fail) return new Response(JSON.stringify({ ok: false, error: 'temporary failure' }), { status: 503 });
    return new Response(JSON.stringify({ ok: true }), { status: 200 });
  };
  const outbox = new SettlementOutbox(null, {
    config: config({
      creditGrantUrl: 'https://yf.example/credit',
      appKey: 'app-secret',
      bucketId: 'bucket-1',
      creditSubmissionEnabled: true,
    }),
    fetchImpl,
    now: () => now,
  });
  outbox.enqueue(result());
  await outbox.process();
  const failed = outbox.get('turn-10');
  assert.equal(failed.creditStatus, 'failed');
  assert.ok(failed.nextAttemptAtMs > now);
  assert.equal(outbox.retryFailed(), false);

  now = failed.nextAttemptAtMs;
  assert.equal(outbox.retryFailed(), true);
  fail = false;
  await outbox.process();
  assert.equal(outbox.get('turn-10').creditStatus, 'confirmed');
});

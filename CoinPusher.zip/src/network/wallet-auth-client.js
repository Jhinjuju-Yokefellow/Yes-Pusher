async function parseResponse(response) {
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload?.ok === false) {
    throw new Error(payload?.error || `Wallet request failed (${response.status})`);
  }
  return payload;
}

function normalizeChainId(value) {
  if (typeof value === 'string' && value.startsWith('0x')) return Number.parseInt(value, 16);
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : null;
}

export class WalletAuthClient {
  constructor({
    provider = globalThis.ethereum,
    onChange = () => {},
  } = {}) {
    this.provider = provider;
    this.onChange = onChange;
    this.session = null;
    this.pending = false;
    this.boundAccountsChanged = (accounts) => {
      const current = String(accounts?.[0] ?? '').toLowerCase();
      if (this.session?.wallet && current !== this.session.wallet.toLowerCase()) {
        void this.disconnect('accounts-changed');
      }
    };
    this.provider?.on?.('accountsChanged', this.boundAccountsChanged);
  }

  get available() {
    return Boolean(this.provider?.request);
  }

  async restore() {
    try {
      const response = await fetch('/api/auth/session', {
        cache: 'no-store',
        credentials: 'same-origin',
      });
      const payload = await parseResponse(response);
      this.session = payload.authenticated ? payload : null;
      this.onChange(this.session, 'restore');
      return this.session;
    } catch {
      this.session = null;
      this.onChange(null, 'restore');
      return null;
    }
  }

  async connect() {
    if (!this.available) throw new Error('No browser wallet was found');
    if (this.pending) return this.session;
    this.pending = true;
    try {
      const accounts = await this.provider.request({ method: 'eth_requestAccounts' });
      const wallet = String(accounts?.[0] ?? '').trim();
      if (!wallet) throw new Error('The wallet did not return an account');
      const rawChainId = await this.provider.request({ method: 'eth_chainId' }).catch(() => null);
      const chainId = normalizeChainId(rawChainId);
      const challengeResponse = await fetch('/api/auth/challenge', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ wallet, chainId }),
      });
      const challenge = await parseResponse(challengeResponse);
      let signature;
      try {
        signature = await this.provider.request({
          method: 'personal_sign',
          params: [challenge.message, wallet],
        });
      } catch (firstError) {
        try {
          signature = await this.provider.request({
            method: 'personal_sign',
            params: [wallet, challenge.message],
          });
        } catch {
          throw firstError;
        }
      }
      const verifyResponse = await fetch('/api/auth/verify', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({
          challengeId: challenge.challengeId,
          wallet,
          signature,
        }),
      });
      this.session = await parseResponse(verifyResponse);
      this.onChange(this.session, 'connect');
      return this.session;
    } finally {
      this.pending = false;
    }
  }

  async disconnect(reason = 'disconnect') {
    await fetch('/api/auth/logout', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      credentials: 'same-origin',
      body: '{}',
    }).catch(() => null);
    this.session = null;
    this.onChange(null, reason);
    return null;
  }

  destroy() {
    this.provider?.removeListener?.('accountsChanged', this.boundAccountsChanged);
  }
}

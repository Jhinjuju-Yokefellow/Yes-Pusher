const PLAYER_ID_KEY = 'yes-pusher:shared-player-id:v1';
const PLAYER_LABEL_KEY = 'yes-pusher:shared-player-label:v1';

function randomId() {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID();
  return `player-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

function loadIdentity() {
  let id;
  let label;
  try {
    id = globalThis.localStorage?.getItem(PLAYER_ID_KEY) || randomId();
    label = globalThis.localStorage?.getItem(PLAYER_LABEL_KEY) || `PLAYER ${id.slice(-4).toUpperCase()}`;
    globalThis.localStorage?.setItem(PLAYER_ID_KEY, id);
    globalThis.localStorage?.setItem(PLAYER_LABEL_KEY, label);
  } catch {
    id = randomId();
    label = `PLAYER ${id.slice(-4).toUpperCase()}`;
  }
  return { id, label };
}

async function parseResponse(response) {
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || `Shared-world request failed (${response.status})`);
  return payload;
}

export class SharedWorldClient {
  constructor({
    onSnapshot = () => {},
    onConnection = () => {},
    onError = () => {},
  } = {}) {
    this.anonymousIdentity = loadIdentity();
    this.playerId = this.anonymousIdentity.id;
    this.playerLabel = this.anonymousIdentity.label;
    this.onSnapshot = onSnapshot;
    this.onConnection = onConnection;
    this.onError = onError;
    this.eventSource = null;
    this.snapshot = null;
    this.connected = false;
  }

  query() {
    const params = new URLSearchParams({
      playerId: this.playerId,
      label: this.playerLabel,
    });
    return params.toString();
  }

  async connect({ retries = 6, retryDelayMs = 250 } = {}) {
    let lastError = null;
    for (let attempt = 0; attempt < retries; attempt += 1) {
      try {
        const response = await fetch(`/api/world?${this.query()}`, {
          cache: 'no-store',
          credentials: 'same-origin',
          signal: AbortSignal.timeout?.(1200),
        });
        const snapshot = await parseResponse(response);
        if (!snapshot.authoritative) throw new Error('Shared world is not authoritative');
        this.acceptSnapshot(snapshot);
        this.openEvents();
        return snapshot;
      } catch (error) {
        lastError = error;
        if (attempt < retries - 1) await new Promise((resolve) => setTimeout(resolve, retryDelayMs));
      }
    }
    throw lastError ?? new Error('Shared world server is unavailable');
  }

  openEvents() {
    this.eventSource?.close();
    const source = new EventSource(`/events?${this.query()}`);
    this.eventSource = source;
    source.addEventListener('open', () => {
      this.connected = true;
      this.onConnection({ connected: true });
    });
    source.addEventListener('world', (event) => {
      try {
        this.acceptSnapshot(JSON.parse(event.data));
      } catch (error) {
        this.onError(error);
      }
    });
    source.addEventListener('error', () => {
      this.connected = false;
      this.onConnection({ connected: false, reconnecting: source.readyState !== EventSource.CLOSED });
    });
  }

  acceptSnapshot(snapshot) {
    if (!snapshot || snapshot.kind !== 'yes-pusher-shared-world') return;
    if (this.snapshot && Number(snapshot.revision) < Number(this.snapshot.revision)) return;
    this.snapshot = snapshot;
    this.onSnapshot(snapshot);
  }


  useSession(session = null) {
    if (session?.authenticated && session.playerId) {
      this.playerId = session.playerId;
      this.playerLabel = session.label || session.wallet || this.playerId;
      return;
    }
    this.playerId = this.anonymousIdentity.id;
    this.playerLabel = this.anonymousIdentity.label;
  }

  async reconnectWithSession(session = null) {
    this.close();
    this.snapshot = null;
    this.useSession(session);
    return this.connect();
  }

  async command(path, values = {}) {
    const response = await fetch(path, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify({
        playerId: this.playerId,
        label: this.playerLabel,
        ...values,
      }),
    });
    const payload = await parseResponse(response);
    if (payload.snapshot) this.acceptSnapshot(payload.snapshot);
    return payload;
  }

  joinQueue() {
    return this.command('/api/queue/join');
  }

  leaveQueue() {
    return this.command('/api/queue/leave');
  }

  startTurn(coins) {
    return this.command('/api/turn/start', { coins });
  }

  close() {
    this.eventSource?.close();
    this.eventSource = null;
    this.connected = false;
  }
}
